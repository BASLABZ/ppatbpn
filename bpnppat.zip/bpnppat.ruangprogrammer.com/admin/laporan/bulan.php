<?php 
	 
	$januari = 'Januari';
	$februari = 'Februari';
	$maret = 'Maret';
	$april = 'April';
	$mei = 'Mei';
	$juni = 'Juni';
	$juli = 'Juli';
	$agustus = 'Agustus';
	$sebtember ='September';
	$oktober = 'Oktober';
	$november = 'November';
	$desember = 'Desember';

	if ($bulan == '01') {
		echo $januari;
	}else if ($bulan == '02') {
		echo $februari;
	}else if ($bulan == '03') {
		echo $maret;
	}else if ($bulan == '04') {
		echo $april;
	}else if ($bulan == '5') {
		echo $mei;
	}else if ($bulan == '6') {
		echo $juni;
	}else if ($bulan == '7') {
		echo $juli;
	}else if ($bulan == '8') {
		echo $agustus;
	}else if ($bulan =='9')  {
		echo $sebtember;
	}else if ($bulan == '10') {
		echo $oktober;
	}else if ($bulan == '11') {
		echo $november;
	}else if ($bulan == '12') {
		echo $desember;
	} 
?>

 